<?php
if($action == 'export') {
     export::exportTables();
}
$sql = sql :: factory();
$DB = dyn :: get('DB');
$prefix = strlen($DB['prefix']);
$sql->query("SHOW TABLES IN ".sql :: $DB_datenbank." LIKE '".dyn :: get('DB') ["prefix"]."%'")->result();
?>
<form action="index.php" method="post">
<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title"><?php echo lang::get('sqlexport')?></h3>
				</div>
                <table class="table">
                    <colgroup>
                        <col width="*">
                        <col width="215">
                    </colgroup>
                    <thead>
                        <tr>
                            <th><?php echo lang::get('name')?></th>
                            <th><?php echo lang::get('exports')?></th>
                        </tr>
                    </thead>
                    <tbody>
<?php
while($sql->isNext())
{
	$name = $sql->result["Tables_in_".sql :: $DB_datenbank." (".dyn :: get('DB') ["prefix"]."%)"];
    $name = substr($name, $prefix);
    echo "
            <tr>
                <td>$name</td>
                <td>
                    <input type=\"checkbox\" name=\"export[$name]\"/>
                </td>
            </tr>";
	$sql->next();
}
?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<input type="hidden" name="page" value="import" class="form-control" />
<input type="hidden" name="subpage" value="export" class="form-control" />
<input type="hidden" name="action" value="export" class="form-control" />
<button type="submit" class="btn-default btn-sm btn" name="save-back"><?php echo lang::get('exports')?></button>
</form>