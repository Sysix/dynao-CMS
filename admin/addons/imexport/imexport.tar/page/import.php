<?php


$page = type::super('page', 'string');
$subpage = type::super('subpage', 'string');
$action = type::super('action', 'string');
backend::addSubnavi(lang::get('import'),	url::backend('import', ['subpage'=>'import']), 	'upload', 0,function() {
return dir::addon('imexport', 'page'.DIRECTORY_SEPARATOR.'import.import.php');
		});

backend::addSubnavi(lang::get('export'),	url::backend('import', ['subpage'=>'export']), 	'download', 0,function() {
			return dir::addon('imexport', 'page'.DIRECTORY_SEPARATOR.'import.export.php');
		});
include_once(backend::getSubnaviInclude());
?>